﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercicio
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Instanciando um objeto da classe Jogo
            Jogo jogo = new Jogo();

            // Preenchendo os atributos do objeto
            jogo.Codigo = 1;
            jogo.Nome = "The Legend of Zelda: Breath of the Wild";
            jogo.Categoria = "Ação, Aventura";
            jogo.DataLancamento = new DateTime(2017, 3, 3);

            // Exibindo os dados do objeto em um MessageBox
            MessageBox.Show($"Código: {jogo.Codigo}\nNome: {jogo.Nome}\nCategoria: {jogo.Categoria}\nData de Lançamento: {jogo.DataLancamento}");
        }
    }

    public class Jogo
    {
        public int Codigo { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
        public DateTime DataLancamento { get; set; }
    }
}
